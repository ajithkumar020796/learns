package com.atmecs.Test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atmecs.Test.entity.EmployeeInt;


@Repository
public interface EmployeeIntRepo extends JpaRepository<EmployeeInt, Integer> {

}
