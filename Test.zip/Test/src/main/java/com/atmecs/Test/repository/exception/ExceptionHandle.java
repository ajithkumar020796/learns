package com.atmecs.Test.repository.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class ExceptionHandle extends RuntimeException {
	
	String a;
	String b;
	Boolean c;

	public ExceptionHandle(String a, String b, Boolean c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}
	@Override
	public String getMessage() {
		return "ExceptionHandle [a=" + a + ", b=" + b + ", c=" + c + "]";
	}
	
	@Override
	public String toString() {
		return "ExceptionHandle [a=" + a + ", b=" + b + ", c=" + c + "]";
	}
	
	
}
