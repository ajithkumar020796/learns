package com.atmecs.Test.service;



import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.atmecs.Test.entity.EmployeeInt;
import com.atmecs.Test.entity.EmployeeString;
import com.atmecs.Test.repository.EmpStringRepo;
import com.atmecs.Test.repository.EmployeeIntRepo;
import com.atmecs.Test.repository.exception.ExceptionHandle;

@Service
public class EmployeeService{
	
	@Autowired
	private EmployeeIntRepo employeeIntRepo;
	
	@Autowired
	private EmpStringRepo empStringRepo;
	
	
	public void saveEmpInt(EmployeeInt employeeInt) {
		employeeIntRepo.save(employeeInt);
	}
	
	public void saveEmpString(EmployeeString employeeString) {
		empStringRepo.save(employeeString);
	}
	
	public ResponseEntity<EmployeeInt> findEmpInt(Integer id) {
		
		if(employeeIntRepo.findById(id).isPresent())
		{
			
			return new ResponseEntity<EmployeeInt>(employeeIntRepo.findById(id).get(), HttpStatus.OK);
		}
		else {
			String status="No Value Present";
			String message="check data base values";
			Boolean b=false;
			throw new ExceptionHandle(status,message,b);
			
		}
		
            	
	}
}
