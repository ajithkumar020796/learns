package com.atmecs.Test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.atmecs.Test.entity.EmployeeInt;
import com.atmecs.Test.entity.EmployeeString;
import com.atmecs.Test.service.EmployeeService;


@RestController
@RequestMapping("/")
public class AppController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/saveEmployeeInt")
	public void saveEmployeeInt(@RequestBody EmployeeInt employeeInt) {
		employeeService.saveEmpInt(employeeInt);
	}
	@PostMapping("/saveEmployeeString")
	public void saveEmpString(@RequestBody EmployeeString employeeString) {
		employeeService.saveEmpString(employeeString);
	}
	
	@GetMapping("/findEmpInt/{id}")
	public @ResponseBody  ResponseEntity<EmployeeInt> findEmpInt(@PathVariable("id") Integer id) {
		if(employeeService.findEmpInt(id)!=null)
		{
			return employeeService.findEmpInt(id);
		}
		else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	
	}

}
