package com.atmecs.Test.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EmployeeInt")
public class EmployeeInt {
	
	@Id
	private Integer id;
	private Integer empInt;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getEmpInt() {
		return empInt;
	}
	public void setEmpInt(Integer empInt) {
		this.empInt = empInt;
	}
	
	
}
