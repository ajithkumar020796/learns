package com.atmecs.Test.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EmployeeString")
public class EmployeeString {
	
	@Id
	private Long id;
	private String empString;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmpString() {
		return empString;
	}
	public void setEmpString(String empString) {
		this.empString = empString;
	}
	@Override
	public String toString() {
		return "EmployeeString [id=" + id + ", empString=" + empString + "]";
	}
	
	

}
