package com.atmecs.Test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atmecs.Test.entity.EmployeeString;

@Repository
public interface EmpStringRepo extends JpaRepository<EmployeeString,Long> {

}
